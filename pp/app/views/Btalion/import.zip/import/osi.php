<?php
// We change the headers of the page so that the browser will know what sort of file is dealing with. Also, we will tell the browser it has to treat the file as an attachment which cannot be cached.
 
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=exceldata.xls");
header("Pragma: no-cache");
header("Expires: 0");
?><!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
            <table>
              <thead>
                 <tr>
                    <th>S.No</th>
                    <th>Battalion</th>
                    <th>Name</th>
                     <th>Present Rank</th>
                      <th>Dept. No </th>
                      <th>Type of Duty</th>
                       <th>Father's Name</th>
                        <th>House no.</th>
                         <th>Street No.</th>
                         <th>Ward No.</th>
                          <th>Village/Mohalla</th>
                           <th>City</th>
                            <th>Post Office</th>
                              <th>Police Station</th>
                              <th> Tehsil</th>
                              <th>District</th>
                               <th>State</th>
                                <th>House no. </th>
                               <th>Street No.</th>
                              <th> Ward No.</th>
                              <th>Village/Mohalla</th>
                               <th>City</th>
                                <th>Post Office </th>
                                 <th>Police Station </th>
                              <th>Tehsil</th>
                               <th>District</th>
                                <th>State</th>
                      <th>Gender</th>
                     <th>Marital Status</th>
                     <th>Date of Birth</th>
                      <th>Caste</th>
                      <th>Category</th>
                       <th>Phone1</th>
                        <th>Phone2</th>
                         <th>Email ID</th>
                         <th>Adhaar no.</th>
                          <th>PAN</th>
                           <th>Name of Bank</th>
                           <th>Name of Branch</th>
                             <th>Bank AC No.</th>
                              <th> IFSC Code</th>
                              <th>Blood Group</th>
                               <th>Identification Mark</th>
                                <th>Feet </th>
                                <th>Height</th>
                              <th> Educational Qualification</th>
                              <th>Mode of Recruitment</th>
                               <th>Date of Enlistment</th>
                                 <th>Rank of Enlistment </th>
                                 <th>Enlistment Category </th>
                              <th>Date of Retirement</th>
                               <th>GPF Pol No </th>
                                <th>Induction Rank</th>
                                  <th> Induction Mode</th>
                              <th>Induction Date</th>
                               <th>Previous Batt./Unit</th>
                                <th>Previous Batt. No. </th>
                                <th>Lower School Course Date</th>
                              <th> Date of List C-I</th>
                              <th>Date of List C-II</th>
                               <th>Date of Offg. HC</th>
                                <th> Inter Mediate School Course  Passing  Date </th>
                                 <th>Date of List-D </th>
                              <th>Date of List-D-II</th>
                               <th>Date of Offg.ASI</th>
                                <th>Upper School Course Passing Date</th>
                                <th>Date of  List E</th>
                                <th> Date of List E-II</th>
                              <th>Date of Offg. SI</th>
                              <th>Date of List-F</th>
                                <th>Date of List-F-II </th>
                                <th>Date of offg. INSP</th>
                              <th> Date of Promotion DSP/ASP</th>
                              <th>Date of Promotion SP</th>
                              <th>Date of Promotion as CR/LR/PR if any</th>
                                <th> Basic Training Course Institute </th>
                                 <th>Batch /GroupNo.</th>
                              <th>Passout Year</th>
                 </tr>
              </thead>
              <tbody>
                <?php  $count = 0; if($weapon!=''){ foreach($weapon as $value): $count = $count+1; ?>
                 <tr class="odd gradeX">
                    <td><?php echo $count; ?></td>
                    <td><?php echo $value->battalion; ?></td>
                    <td> <?php echo $value->name; ?></td>
                    <td><?php echo $value->presentrank; ?></td>
                    <td><?php echo $value->depttno; ?></td>
                    <td><?php echo $value->typeofduty; ?></td>
                    <td><?php echo $value->fathername; ?></td>
                    <td><?php echo $value->houseno; ?></td>
                    <td><?php echo $value->streetno; ?></td>
                    <td><?php echo $value->wardno; ?></td>
                    <td><?php echo $value->villmohala; ?></td>
                    <td><?php echo $value->city; ?></td>
                    <td><?php echo $value->postoffice; ?></td>
                     <td><?php echo $value->policestation; ?></td>
                    <td><?php echo $value->teshil; ?></td>
                    <td><?php echo $value->district; ?></td>
                    <td><?php echo $value->state; ?></td>
                    <td><?php echo $value->phouse; ?></td>
                     <td><?php echo $value->pstreet; ?></td>
                    <td><?php echo $value->pward; ?></td>
                    <td><?php echo $value->pvillmohala; ?></td>
                    <td><?php echo $value->pcity; ?></td>
                    <td><?php echo $value->ppostoffice; ?></td>
                     <td><?php echo $value->ppolicestation; ?></td>
                    <td><?php echo $value->ptehsil; ?></td>
                    <td><?php echo $value->pdistrict; ?></td>
                    <td><?php echo $value->pstate; ?></td>
                    <td><?php echo $value->gender; ?></td>
                    <td><?php echo $value->maritalstatus; ?></td>
                    <td><?php echo $value->dateofbith; ?></td>
                    <td><?php echo $value->caste; ?></td>
                    <td><?php echo $value->category; ?></td>
                    <td><?php echo $value->phono1; ?></td>
                      <td><?php echo $value->phono2; ?></td>
                    <td><?php echo $value->email; ?></td>
                    <td><?php echo $value->adharno; ?></td>
                    <td><?php echo $value->pan; ?></td>
                    <td><?php echo $value->nameofbank; ?></td>
                    <td><?php echo $value->nameofbranch; ?></td>
                    <td><?php echo $value->bankacno; ?></td>
                    <td><?php echo $value->ifsccode; ?></td>
                    <td><?php echo $value->bloodgroup; ?></td>
                    <td><?php echo $value->identificationmark ; ?></td>
                    <td><?php echo $value->feet; ?></td>
                     <td><?php echo $value->inch; ?></td>
                     <td><?php echo $value->eduqalification; ?></td>   
                    <td><?php echo $value->modeofrec; ?></td>
                    <td><?php echo $value->dateofinlitment; ?></td>
                     <td><?php echo $value->rankofenlistment; ?></td>
                    <td><?php echo $value->enlistmentcat; ?></td>
                    <td><?php echo $value->dateofretirment; ?></td>
                    <th><?php echo $value->gpfpranno; ?></th>
                    <td><?php echo $value->inductionrank; ?></td>
                    <td><?php echo $value->inductionmode; ?></td>
                     <td><?php echo $value->inductiondate; ?></td>
                     <td><?php echo $value->prebattalion; ?></td>
                    <td><?php echo $value->prebattno; ?></td>
                     <td><?php echo $value->loweschoolcdate; ?></td>
                    <td><?php echo $value->doc1; ?></td>
                      <td><?php echo $value->doc2; ?></td>
                    <td><?php echo $value->dofhc; ?></td>
                    <td><?php echo $value->intermediatescor; ?></td>
                    <td><?php echo $value->dofld; ?></td>
                    <td><?php echo $value->dofld2; ?></td>
                    <td><?php echo $value->dateofoffasi; ?></td>
                    <td><?php echo $value->upperschool; ?></td>
                    <td><?php echo $value->dateofliste; ?></td>
                    <td><?php echo $value->dateofliste2; ?></td>
                    <td><?php echo $value->dateoffsi; ?></td>
                    <td><?php echo $value->dateoflistf; ?></td>
                    <td><?php echo $value->dateoflistf2; ?></td>
                    <td><?php echo $value->dateofinsp; ?></td>
                    <td><?php echo $value->dopdasp; ?></td>
                    <td><?php echo $value->doprosp; ?></td>
                    <td><?php echo $value->doprocl; ?></td>
                    <td><?php echo $value->btic; ?></td>
                     <td><?php echo $value->batchgroup; ?></td>
                    <td><?php echo $value->passoutyear; ?></td>
                    
                    </tr>
                <?php endforeach; } ?>
              </tbody>
           </table>
      
</body>
</html>