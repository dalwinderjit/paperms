<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="<?php echo base_url(); ?>webroot/images/favicon.png" type="image/png">
    <title> Man Power Module</title>
    <link rel="stylesheet" href="<?php echo base_url(); ?>webroot/css/style.default.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css"/>
    <link rel="stylesheet" href="https://datatables.net/release-datatables/extensions/ColVis/css/dataTables.colVis.css"/>
    <style type="text/css">
    .cur{
      cursor: pointer;
    }
    </style>
</head>
<body>
<!-- Preloader -->
<div id="preloader">
    <div id="status"><i class="fa fa-spinner fa-spin"></i></div>
</div>

<section>
<?php $this->load->view('Btalion/html/navbar'); ?>
  <div class="mainpanel">
<?php $this->load->view('Btalion/html/headbar'); ?>
    <div class="pageheader">
      <h2><i class="fa fa-building-o"></i> Man Power Module</h2>
      <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
          <li class="active"><a href="<?php echo base_url();?>bt-dashboard">Dashboard</a></li>
          <li class="active"> Man Power Module</li>
        </ol>
      </div>
    </div>

    <div class="contentpanel">  
      <div class="row">
        <div class="col-sm-12">
       <?php if($this->session->flashdata('success_msg')): ?>
        <div class="alert alert-success alert-dismissible" id="warning" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Success!</strong> <?php echo $this->session->flashdata('success_msg'); ?>
</div>
      <?php  endif; ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <?php 
 /*Form Validation set*/
 $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
  /*----End Form Validation----*/
  
 /*Create HTML form*/
 $attributes = array(
      'name'        => 'basicForm4',
      'id'        => 'basicForm4',
      'accept-charset'  => 'utf-8',
      'autocomplete'    =>'off', 
      );
 echo form_open_multipart("", $attributes);
?>
          <div class="row">
                
                  <div class="col-sm-3"><div class="form-group">
<?php
$bloodgroup = array('' => '--Select Blood Group--',  'O +ve' => 'O +ve', 'O –ve' => 'O –ve', 'A +ve' => 'A +ve', 'A –ve' => 'A –ve', 'AB +ve' => 'AB +ve', 'AB –ve' => 'AB –ve','B+ve' => 'B+ve', 'B-ve' => 'B-ve' );
/*newarea Textfield*/
 echo form_dropdown('bloodgroup', $bloodgroup, set_value('bloodgroup',1),'id="bloodgroup" data-placeholder="Choose One" class="select2"'); 
 echo form_error('bloodgroup');
?>
                    <label for="bloodgroup" class="error"></label>
                  </div>
                </div>

                   
                   <div class="col-sm-3"> <div class="form-group">
<?php
$rcnum = array('type' => 'text','name' => 'rcnum','id' => 'rcnum','class' => 'form-control','placeholder' =>'Dept No.','value' => set_value('rcnum'));
echo form_input($rcnum);
echo form_error('rcnum');
?>
                    <label for="rcnum" class="error"></label>
                  </div>
                </div>

                 <div class="col-sm-3"><div class="form-group">
                <?php  
$RankRankre = array('' => '--Present Rank--', 'CT' => 'CT', 'Sr. Const' => 'Sr. Const', 'C-II' => 'C-II', 'HC/PR' => 'HC/PR', 'HC' => 'HC', 'ASI/LR' => 'ASI/LR','ASI/CR' => 'ASI/CR',  'ASI' => 'ASI', 'SI/CR' => 'SI/CR','SI/LR' => 'SI/LR', 'SI' => 'SI', 'INSP/CR' => 'INSP/CR','INSP/LR' => 'INSP/LR', 'INSP' => 'INSP', 'DSP/CR' =>'DSP/CR','DSP' =>'DSP', 'SP/CR' => 'SP/CR', 'SP' => 'SP','Asst. Commandant' =>'Asst. Commandant','Commandant' => 'Commandant');
 echo form_dropdown('RankRankre', $RankRankre, set_value('RankRankre',1),'id="RankRankre" data-placeholder="Choose One" class="select2"'); 
 echo form_error('RankRankre');
 ?>
                    <label for="Receivedfrom" class="error"></label>
                  </div>
                </div>

                 
                  <div class="col-sm-3"><div class="form-group">
<?php
$iIdentityCardNocn = array('type' => 'text','name' => 'iIdentityCardNocn','id' => 'iIdentityCardNocn','class' => 'form-control','placeholder' =>'Identity Card No.','value' => set_value('iIdentityCardNocn'));
echo form_input($iIdentityCardNocn);
echo form_error('iIdentityCardNocn');
?>
                    <label for="iIdentityCardNocn" class="error"></label>
                  </div>
                </div>
                </div><br/>

                  <div class="row">

                  <div class="col-sm-3"> <div class="form-group">

                       <?php 
                 $postate = array();
                  $postate[''] = '--Select State--'; 
                 foreach ($statelist as $value) {
                   $postate[$value->state] = $value->state;
                 }

 ?>
            <?php  
/*newarea Textfield*/
 echo form_dropdown('postate', $postate, set_value('postate','Punjab'),'id="postate" data-placeholder="Choose One" title="Please select at least 1 area" class="select2"'); 
 echo form_error('postate');
/*----End newarea Textfield----*/
 ?>
                    <label for="postate" class="error"></label>
                  </div>
                </div>

                  <div class="col-sm-3"> <div class="form-group">

                       <?php 
                 $pcity = array();
                  $pcity[''] = '--Select City--'; 
                 foreach ($statelist as $value) {
                   $pcity[$value->city] = $value->city;
                 }

 ?>
            <?php  
/*newarea Textfield*/
 echo form_dropdown('pcity', $pcity, set_value('pcity',''),'id="pcity" data-placeholder="--Select City--" title="Please select at least 1 area" class="select2"'); 
 echo form_error('pcity');
/*----End newarea Textfield----*/
 ?>
                    <label for="pcity" class="error"></label>
                  </div>
                </div>


                  
                  <div class="col-sm-3"><div class="form-group">
                 <?php  
$stts = array('' => '--Education--',  'Illiterate' => 'Illiterate', 'Under Matric' => 'Under Matric', '10th' => '10th', 'H. Sec' => 'H. Sec', 'Prep' => 'Prep', '10+1' => '10+1','10+2' =>'10+2','Under Graduate' => 'Under Graduate', 'Graduate' => 'Graduate', 'Post Graduate' => 'Post Graduate','Doctorate' => 'Doctorate');
/*newarea Textfield*/
 echo form_dropdown('stts', $stts, set_value('stts',1),'id="stts" data-placeholder="Choose One" class="select2"'); 
 echo form_error('stts');
/*----End newarea Textfield----*/
 ?>
                    <label for="stts" class="error"></label>
                  </div>
                </div> 

                  <div class="col-sm-3"><div class="form-group">
<?php
$iIdentityCardNocn = array('type' => 'text','name' => 'iIdentityCardNocn','id' => 'iIdentityCardNocn','class' => 'form-control','placeholder' =>'Offical Name','value' => set_value('iIdentityCardNocn'));
echo form_input($iIdentityCardNocn);
echo form_error('iIdentityCardNocn');
?>
                    <label for="iIdentityCardNocn" class="error"></label>
                  </div>
                </div>

                 </div>

                        <br/><div class="row">
                <div class="col-sm-3">
                <div class="form-group">
<?php
$gender = array('' => '--Select Gender--',  'Male' => 'Male', 'Female' => 'Female');
/*newarea Textfield*/
 echo form_dropdown('gender', $gender, set_value('gender',1),'id="gender" data-placeholder="Choose One" class="select2"'); 
 echo form_error('gender');
?>
                    <label for="gender" class="error"></label>
                  </div>
                </div>

                <div class="col-sm-3">
                <div class="form-group">
<?php
$gender = array('' => '--Select Matrial--',  'Married' => 'Married', 'Single' => 'Single');
/*newarea Textfield*/
 echo form_dropdown('gender', $gender, set_value('gender',1),'id="gender" data-placeholder="Choose One" class="select2"'); 
 echo form_error('gender');
?>
                    <label for="gender" class="error"></label>
                  </div>
                </div>


                 
                  <div class="col-sm-3"><div class="form-group">
                 <?php  
$Modemdr = array('' => '--Mode of Recruitment--', 'Special Cases' => 'Special Cases','Direct' => 'Direct', 'Direct (Ex-Serviceman)' => 'Direct (Ex-Serviceman)','Direct(SPORTS)' => 'Direct(SPORTS)', 'PLI' => 'PLI', 'Court cases' => 'Court cases','Direct (Freedom Fighter)' => 'Direct (Freedom Fighter)');
/*newarea Textfield*/
 echo form_dropdown('Modemdr', $Modemdr, set_value('Modemdr',1),'id="Modemdr" data-placeholder="Choose One" title="Please select at least 1 area" class="select2"'); 
 echo form_error('Modemdr');
/*----End newarea Textfield----*/
 ?>
                    <label for="Modemdr" class="error"></label>
                  </div>
                </div> 


                 <div class="col-sm-3"><div class="form-group">
                 <?php  
$Modemdr = array('' => '--Mode of Recruitment--', 'Special Cases' => 'Special Cases','Direct' => 'Direct', 'Direct (Ex-Serviceman)' => 'Direct (Ex-Serviceman)','Direct(SPORTS)' => 'Direct(SPORTS)', 'PLI' => 'PLI', 'Court cases' => 'Court cases','Direct (Freedom Fighter)' => 'Direct (Freedom Fighter)');
/*newarea Textfield*/
 echo form_dropdown('Modemdr', $Modemdr, set_value('Modemdr',1),'id="Modemdr" data-placeholder="Choose One" title="Please select at least 1 area" class="select2"'); 
 echo form_error('Modemdr');
/*----End newarea Textfield----*/
 ?>
                    <label for="Modemdr" class="error"></label>
                  </div>
                </div> 
</div>
<br/>
<div class="row">
         <div class="col-sm-3"><div class="form-group">
                 <?php  
$Rankre = array('' => '--Rank of Enlistment--',  'Constable' => 'Constable', 'ASI' =>'ASI','SI' => 'SI', 'Insp' => 'Insp', 'DSP' => 'DSP', 'ASP' =>'ASP');
 echo form_dropdown('Rankre', $Rankre, set_value('Rankre',1),'id="Rankre" data-placeholder="Choose One" class="select2"'); 
 echo form_error('Rankre');
 ?>
                    <label for="Rankre" class="error"></label>
                  </div>
                </div> 

                  
                  <div class="col-sm-3"><div class="form-group">
                 <?php  
$Enlistmentec = array('' => '--Enlistment Category--', 'GEN' => 'GEN', 'SCO' => 'SCO','SCBM' => 'SCBM', 'BC' => 'BC', 'OBC' => 'OBC', 'ST' => 'ST', 'NA' => 'NA');
 echo form_dropdown('Enlistmentec', $Enlistmentec, set_value('Enlistmentec',1),'id="Enlistmentec" data-placeholder="Choose One" title="Please select at least 1 area" class="select2"'); 
 echo form_error('Enlistmentec');
 ?>
                    <label for="Enlistmentec" class="error"></label>
                  </div>
                </div> 



                  <div class="col-sm-3"> <div class="form-group">
                 <?php  
$InductionModeim = array('' => '--Induction Mode--', 'Transfer' => 'Transfer', 'Transfer(Promotion)' => 'Transfer(Promotion)', 'Transfer(Excess)' => 'Transfer(Excess)', 'Attachment' => 'Attachment','Transfer Pay Purpose' => 'Transfer Pay Purpose');
 echo form_dropdown('InductionModeim', $InductionModeim, set_value('InductionModeim',1),'id="InductionModeim" data-placeholder="Choose One" class="select2"'); 
 echo form_error('InductionModeim');
 ?>
                    <label for="InductionModeim" class="error"></label>
                  </div>
                </div> 



                <div class="col-sm-3">
                   <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                </div>

</div>

<?php echo form_close(); ?>
          </div>
        <div class="panel-body"> 
          <!-- Example split danger button -->
          <div class="table-responsive">
            <table class="table"  id="table">
              <thead>
                 <tr>
                    <th>S.No</th>
                    <th>Battalion</th>
                    <th>Name</th>
                     <th>Present Rank</th>
                      <th>Dept. No </th>
                      <th>Type of Duty</th>
                       <th>Father's Name</th>
                        <th>House no.</th>
                         <th>Street No.</th>
                         <th>Ward No.</th>
                          <th>Village/Mohalla</th>
                           <th>City</th>
                            <th>Post Office</th>
                              <th>Police Station</th>
                              <th> Tehsil</th>
                              <th>District</th>
                               <th>State</th>
                                <th>House no. </th>
                               <th>Street No.</th>
                              <th> Ward No.</th>
                              <th>Village/Mohalla</th>
                               <th>City</th>
                                <th>Post Office </th>
                                 <th>Police Station </th>
                              <th>Tehsil</th>
                               <th>District</th>
                                <th>State</th>
                      <th>Gender</th>
                     <th>Marital Status</th>
                     <th>Date of Birth</th>
                      <th>Caste</th>
                      <th>Category</th>
                       <th>Phone1</th>
                        <th>Phone2</th>
                         <th>Email ID</th>
                         <th>Adhaar no.</th>
                          <th>PAN</th>
                           <th>Name of Bank</th>
                           <th>Name of Branch</th>
                             <th>Bank AC No.</th>
                              <th> IFSC Code</th>
                              <th>Blood Group</th>
                               <th>Identification Mark</th>
                                <th>Feet </th>
                                <th>Height</th>
                              <th> Educational Qualification</th>
                              <th>Mode of Recruitment</th>
                               <th>Date of Enlistment</th>
                                 <th>Rank of Enlistment </th>
                                 <th>Enlistment Category </th>
                              <th>Date of Retirement</th>
                               <th>GPF Pol No </th>
                                <th>Induction Rank</th>
                                  <th> Induction Mode</th>
                              <th>Induction Date</th>
                               <th>Previous Batt./Unit</th>
                                <th>Previous Batt. No. </th>
                                <th>Lower School Course Date</th>
                              <th> Date of List C-I</th>
                              <th>Date of List C-II</th>
                               <th>Date of Offg. HC</th>
                                <th> Inter Mediate School Course  Passing  Date </th>
                                 <th>Date of List-D </th>
                              <th>Date of List-D-II</th>
                               <th>Date of Offg.ASI</th>
                                <th>Upper School Course Passing Date</th>
                                <th>Date of  List E</th>
                                <th> Date of List E-II</th>
                              <th>Date of Offg. SI</th>
                              <th>Date of List-F</th>
                                <th>Date of List-F-II </th>
                                <th>Date of offg. INSP</th>
                              <th> Date of Promotion DSP/ASP</th>
                              <th>Date of Promotion SP</th>
                              <th>Date of Promotion as CR/LR/PR if any</th>
                                <th> Basic Training Course Institute </th>
                                 <th>Batch /GroupNo.</th>
                              <th>Passout Year</th>
                 </tr>
              </thead>
              <tbody>
                <?php  $count = 0; foreach($weapon as $value): $count = $count+1; ?>
                 <tr class="odd gradeX">
                    <td><?php echo $count; ?></td>
                    <td><?php echo $value->battalion; ?></td>
                    <td><a href="<?php echo base_url('bt-updates-manpower/'.$value->man_id); ?>" target="_blank"> <?php echo $value->name; ?></a></td>
                    <td><?php echo $value->presentrank; ?></td>
                    <td><?php echo $value->depttno; ?></td>
                    <td><?php echo $value->typeofduty; ?></td>
                    <td><?php echo $value->fathername; ?></td>
                    <td><?php echo $value->houseno; ?></td>
                    <td><?php echo $value->streetno; ?></td>
                    <td><?php echo $value->wardno; ?></td>
                    <td><?php echo $value->villmohala; ?></td>
                    <td><?php echo $value->city; ?></td>
                    <td><?php echo $value->postoffice; ?></td>
                     <td><?php echo $value->policestation; ?></td>
                    <td><?php echo $value->teshil; ?></td>
                    <td><?php echo $value->district; ?></td>
                    <td><?php echo $value->state; ?></td>
                    <td><?php echo $value->phouse; ?></td>
                     <td><?php echo $value->pstreet; ?></td>
                    <td><?php echo $value->pward; ?></td>
                    <td><?php echo $value->pvillmohala; ?></td>
                    <td><?php echo $value->pcity; ?></td>
                    <td><?php echo $value->ppostoffice; ?></td>
                     <td><?php echo $value->ppolicestation; ?></td>
                    <td><?php echo $value->ptehsil; ?></td>
                    <td><?php echo $value->pdistrict; ?></td>
                    <td><?php echo $value->pstate; ?></td>
                    <td><?php echo $value->gender; ?></td>
                    <td><?php echo $value->maritalstatus; ?></td>
                    <td><?php echo $value->dateofbith; ?></td>
                    <td><?php echo $value->caste; ?></td>
                    <td><?php echo $value->category; ?></td>
                    <td><?php echo $value->phono1; ?></td>
                      <td><?php echo $value->phono2; ?></td>
                    <td><?php echo $value->email; ?></td>
                    <td><?php echo $value->adharno; ?></td>
                    <td><?php echo $value->pan; ?></td>
                    <td><?php echo $value->nameofbank; ?></td>
                    <td><?php echo $value->nameofbranch; ?></td>
                    <td><?php echo $value->bankacno; ?></td>
                    <td><?php echo $value->ifsccode; ?></td>
                    <td><?php echo $value->bloodgroup; ?></td>
                    <td><?php echo $value->identificationmark ; ?></td>
                    <td><?php echo $value->feet; ?></td>
                     <td><?php echo $value->inch; ?></td>
                     <td><?php echo $value->eduqalification; ?></td>   
                    <td><?php echo $value->modeofrec; ?></td>
                    <td><?php echo $value->dateofinlitment; ?></td>
                     <td><?php echo $value->rankofenlistment; ?></td>
                    <td><?php echo $value->enlistmentcat; ?></td>
                    <td><?php echo $value->dateofretirment; ?></td>
                    <th><?php echo $value->gpfpranno; ?></th>
                    <td><?php echo $value->inductionrank; ?></td>
                    <td><?php echo $value->inductionmode; ?></td>
                     <td><?php echo $value->inductiondate; ?></td>
                     <td><?php echo $value->prebattalion; ?></td>
                    <td><?php echo $value->prebattno; ?></td>
                     <td><?php echo $value->loweschoolcdate; ?></td>
                    <td><?php echo $value->doc1; ?></td>
                      <td><?php echo $value->doc2; ?></td>
                    <td><?php echo $value->dofhc; ?></td>
                    <td><?php echo $value->intermediatescor; ?></td>
                    <td><?php echo $value->dofld; ?></td>
                    <td><?php echo $value->dofld2; ?></td>
                    <td><?php echo $value->dateofoffasi; ?></td>
                    <td><?php echo $value->upperschool; ?></td>
                    <td><?php echo $value->dateofliste; ?></td>
                    <td><?php echo $value->dateofliste2; ?></td>
                    <td><?php echo $value->dateoffsi; ?></td>
                    <td><?php echo $value->dateoflistf; ?></td>
                    <td><?php echo $value->dateoflistf2; ?></td>
                    <td><?php echo $value->dateofinsp; ?></td>
                    <td><?php echo $value->dopdasp; ?></td>
                    <td><?php echo $value->doprosp; ?></td>
                    <td><?php echo $value->doprocl; ?></td>
                    <td><?php echo $value->btic; ?></td>
                     <td><?php echo $value->batchgroup; ?></td>
                    <td><?php echo $value->passoutyear; ?></td>
                    
                    </tr>
                <?php endforeach; ?>
              </tbody>
           </table>
          </div><!-- table-responsive -->  
          <?php echo $links; ?> 
        </div><!-- panel-body -->
        </div><!-- panel -->
      </div><!-- col-sm-12 -->
    </div><!-- row -->
    </div><!-- contentpanel -->
  </div><!-- mainpanel -->
</section>
<script src="<?php echo base_url();?>webroot/js/jquery-2.1.3.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery-ui-1.10.3.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/modernizr.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/toggles.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/retina.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery.cookies.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery.mousewheel.js"></script>
<script src="<?php echo base_url();?>webroot/js/select2.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/bootstrap-timepicker.min.js"></script>

<script src="<?php echo base_url();?>webroot/js/custom.js"></script>

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://datatables.net/release-datatables/extensions/ColVis/js/dataTables.colVis.js"></script>
<script type="text/javascript">
jQuery(document).ready(function(){
  "use strict";
  jQuery("select").select2({width:"100%"}),
  jQuery("select").removeClass("form-control"),

  jQuery('#ircd').datepicker({dateFormat: "dd/mm/yy"});
  jQuery('#id').datepicker({dateFormat: "dd/mm/yy"});
  jQuery('#ircdi').datepicker({dateFormat: "dd/mm/yy"});
  jQuery('#idi').datepicker({dateFormat: "dd/mm/yy"});
});
   

$(document).ready(function() {
var table = $('#table').DataTable( {
         dom: 'C<"clear">Bfrtip',

       buttons: [
            {
               extend: 'excel',
                exportOptions: {
                    columns: ':visible'
                }
            },{
               extend: 'print',
                exportOptions: {
                    columns: ':visible'
                }
            },{
               extend: 'csv',
                exportOptions: {
                    columns: ':visible'
                }
            },{
               extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            }
        ],
        colVis: {
            exclude: [ 0 ]
        },
        scrollY: 300,
        scrollX: 800,
    columnDefs: [
    { "visible": false, "targets": '_all' }
  ]
    } );
  

});
</script>
</body>
</html>