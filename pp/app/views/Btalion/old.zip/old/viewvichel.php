<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="<?php echo base_url(); ?>webroot/images/favicon.png" type="image/png">
    <title>MT Module</title>
    <link rel="stylesheet" href="<?php echo base_url(); ?>webroot/css/style.default.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css"/>
    <link rel="stylesheet" href="https://datatables.net/release-datatables/extensions/ColVis/css/dataTables.colVis.css"/>
    <style type="text/css">
    .cur{
      cursor: pointer;
    }
    </style>
</head>
<body>
<!-- Preloader -->
<div id="preloader">
    <div id="status"><i class="fa fa-spinner fa-spin"></i></div>
</div>

<section>
<?php $this->load->view('Btalion/html/navbar'); ?>
  <div class="mainpanel">
<?php $this->load->view('Btalion/html/headbar'); ?>
    <div class="pageheader">
      <h2><i class="fa fa-building-o"></i> MT Module</h2>
      <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
          <li class="active"><a href="<?php echo base_url();?>bt-dashboard">Dashboard</a></li>
          <li class="active">MT Module</li>
        </ol>
      </div>
    </div>

    <div class="contentpanel">  
      <div class="row">
        <div class="col-sm-12">
       <?php if($this->session->flashdata('success_msg')): ?>
        <div class="alert alert-success alert-dismissible" id="warning" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Success!</strong> <?php echo $this->session->flashdata('success_msg'); ?>
</div>
      <?php  endif; ?>
    <div class="panel panel-default">
        <div class="panel-heading">
           <div class="row">
          <?php 
 /*Form Validation set*/
 $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
  /*----End Form Validation----*/
  
 /*Create HTML form*/
 $attributes = array(
      'name'        => 'basicForm4',
      'id'        => 'basicForm4',
      'accept-charset'  => 'utf-8',
      'autocomplete'    =>'off', 
      );
 echo form_open_multipart("", $attributes);
?>
   

                  <div class="col-sm-3"><div class="form-group">
                 <?php  
$cov = array('' => '--Select Make of Vehicle--', 'BUS 52 Seater (Tata)' => 'BUS 52 Seater (Tata)', 'Truck (Tata' => 'Truck (Tata', 'Canter Tata 407' => 'Canter Tata 407', 'Canter S/Mazada' => 'Canter S/Mazada', 'Canter Tata 407' => 'Canter Tata 407', 'Eicher (M/Bus)' => 'Eicher (M/Bus)', 'S/Mazada (Ambulance)' => 'S/Mazada (Ambulance)', 'M/Cycle (Royel Enfield)' => 'M/Cycle (Royel Enfield)', 'M/Cycle (Bajaj Pulsar)' => 'M/Cycle (Bajaj Pulsar)', 'Toyota (Kirloskar Motor)' => 'Toyota (Kirloskar Motor)','M & M  (Bolero)' => 'M & M  (Bolero)', 'M & M Xylo' => 'M & M Xylo', 'Maruti Suzuki (Ertiga)' =>'Maruti Suzuki (Ertiga)', 'M & M (Scarpio)' => 'M & M (Scarpio)', 'Tata Sumo' => 'Tata Sumo','Gypsy' =>'Gypsy');
/*newarea Textfield*/
 echo form_dropdown('cov', $cov, set_value('cov',1),'id="cov" data-placeholder="Choose One" title="Please select at least 1 area" class="select2"'); 
 echo form_error('cov');
/*----End newarea Textfield----*/
 ?>
                    <label for="toi" class="error"></label>
                  </div>
                </div>

                   
                  <div class="col-sm-3"> <div class="form-group">
                 <?php  
$vc = array('' => '--Select Vehicle Class--', 'LMV' => 'LMV','HTV' => 'HTV', 'HMV' => 'HMV', 'MMV' => 'MMV', 'Two Wheeler' => 'Two Wheeler');
/*newarea Textfield*/
 echo form_dropdown('vc', $vc, set_value('vc',1),'id="vc" data-placeholder="Choose One" title="Please select at least 1 area" class="select2"'); 
 echo form_error('vc');
 ?>
                    <label for="nameofitem" class="error"></label><p id="link"></p>
                  </div>
                </div>

                   
                  <div class="col-sm-3"><div class="form-group">

                <select name="dob1" class="select2">
                 <option value="">--Select Vehicle model year--</option>
                    <?php for ($i=1950; $i <2017 ; $i++) { ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                    <?php } ?></select>
                    <label for="cti" class="error"></label>
                  </div>
                </div>

                  <div class="col-sm-3"><div class="form-group">

           <?php  
$option = array('' => '--Option--', 'In Store' => 'In Store','Issued' => 'Issued');
/*newarea Textfield*/
 echo form_dropdown('option', $option, set_value('option',1),'id="option" data-placeholder="Choose One" title="Please select at least 1 value" class="select2"'); 
 echo form_error('option'); ?>
                    <label for="option" class="error"></label>
                  </div>
                </div>

                </div>

                 <div class="row">
            

                  <div class="col-sm-3"> <div class="form-group">
<?php
$rcnum = array('type' => 'text','name' => 'rcnum','id' => 'rcnum','class' => 'form-control','placeholder' =>'Engine No.','value' => set_value('rcnum'));
echo form_input($rcnum);
echo form_error('rcnum');
?>
                    <label for="rcnum" class="error"></label>
                  </div>
                </div>

                 <div class="col-sm-3"> <div class="form-group">
<?php
$rcnum = array('type' => 'text','name' => 'rcnum','id' => 'rcnum','class' => 'form-control','placeholder' =>'Chasis No.','value' => set_value('rcnum'));
echo form_input($rcnum);
echo form_error('rcnum');
?>
                    <label for="rcnum" class="error"></label>
                  </div>
                </div>

                  <div class="col-sm-3"><div class="form-group">
                 <?php  
$moa = array('' => '--Select Registration Type--', 'Temporary' =>'Temporary', 'Permanent' => 'Permanent');
/*newarea Textfield*/
 echo form_dropdown('moa', $moa, set_value('moa',1),'id="moa" data-placeholder="Choose One" title="Please select at least 1 value" class="select2"'); 
 echo form_error('moa');
/*----End newarea Textfield----*/
 ?>
                    <label for="fname" class="error"></label>
                  </div>
                </div> 

                 
                  <div class="col-sm-3"> <div class="form-group">
<?php
$rcnum = array('type' => 'text','name' => 'rcnum','id' => 'rcnum','class' => 'form-control','placeholder' =>'Registration No.','value' => set_value('rcnum'));
echo form_input($rcnum);
echo form_error('rcnum');
?>
                    <label for="rcnum" class="error"></label>
                  </div>
                </div>
                </div>

                  <div class="row">
                    
                       
                  <div class="col-sm-3"><div class="form-group">
                <?php  
$rm = array('' => '--Select Received Mode--', 'Received,' =>'Received', 'Attached' => 'Attached');
/*newarea Textfield*/
 echo form_dropdown('rm', $rm, set_value('rm',1),'id="rm" data-placeholder="Choose One" title="Please select at least 1 value" class="select2"'); 
 echo form_error('rm');
/*----End newarea Textfield----*/
 ?>
                    <label for="ofname" class="error"></label>
                  </div>
                </div> 

                 
                  <div class="col-sm-3"><div class="form-group">
<?php
$rv = array('type' => 'text','name' => 'rv','id' => 'rv','class' => 'form-control','placeholder' =>'Received Voucher/RC No.','value' => set_value('rv'));
echo form_input($rv);
echo form_error('rv');
?>
                    <label for="run" class="error"></label>
                  </div>
                </div> 

                 <div class="col-sm-3"> <div class="form-group">
<?php  
$vcon = array('' => '--Select Vehicle Condition--', 'Good' => 'Good', 'Normal' => 'Normal','Bad' => 'Bad');
/*newarea Textfield*/
 echo form_dropdown('vcon', $vcon, set_value('vcon',1),'id="vcon" data-placeholder="Choose One" title="Please select at least 1 value" class="select2"'); 
 echo form_error('vcon');
/*----End newarea Textfield----*/
 ?>
                    <label for="billno" class="error"></label>
                  </div>
                </div>

                  <div class="col-sm-3"> <div class="form-group">
                 <?php  
$moa = array('' => '--Select Issue mode--', 'Permanent' =>'Permanent', 'Temporary' => 'Temporary');
/*newarea Textfield*/
 echo form_dropdown('moa', $moa, set_value('moa',1),'id="moa" data-placeholder="Choose One" title="Please select at least 1 value" class="select2"'); 
 echo form_error('moa');
/*----End newarea Textfield----*/
 ?>
                    <label for="moa" class="error"></label>
                  </div>
                </div> 

                  </div>

                  <div class="row">
                         
                  <div class="col-sm-3"><div class="form-group">
                 <?php  
$tpi = array('' => '--Select Place of duty--', 'MT' => 'MT','Office' => 'Office');
/*newarea Textfield*/
 echo form_dropdown('tpi', $tpi, set_value('tpi',1),'id="tpi" data-placeholder="Choose One" title="Please select at least 1 area" class="select2"'); 
 echo form_error('tpi');
/*----End newarea Textfield----*/
 ?>
                    <label for="tpi" class="error"></label>
                  </div>
                </div> 

                   <div class="col-sm-3"><div class="form-group">

                 <?php 
                 $nop = array();
                 $nop[''] = '---Select Name of official---';
                 foreach ($officer as $value) {
                   $nop[$value->officer_master_id] = $value->off_name;
                 } 
/*newarea Textfield*/
 echo form_dropdown('nop', $nop, set_value('nop',1),'id="nop" data-placeholder="Choose One" title="Please select at least 1 area" class="select2"'); 
 echo form_error('nop');
/*----End newarea Textfield----*/
 ?>
                    <label for="nop" class="error"></label>
                  </div>
                </div>

                      
                  <div class="col-sm-3"><div class="form-group">
                 <?php  
                $ito = array('' => '--Select Battalion--','34' => '7-PAP','9-PAP' => '9-PAP', '13-PAP' => '13-PAP','48' => '27-PAP','36-PAP' => '36-PAP','9' => '75-PAP','55' => '80-PAP','82-PAP' => '82-PAP', 'CCR' => 'CCR', 'CR-PAP' => 'CR-PAP','76' => 'RTC-PAP','ISTC-KPT' => 'ISTC-KPT','CTC-PTL' => 'CTC-PTL','CONTROL-ADGP' => 'CONTROL-ADGP','69' => 'CSO','1-CDO' => '1-CDO','2-CDO' => '2-CDO', '3-CDO' => '3-CDO', '4-CDO' => '4-CDO','5-CDO' => '5-CDO','1-IRB' => '1-IRB','2-IRB' => '2-IRB', '3-IRB' => '3-IRB', '4-IRB' => '4-IRB','5-IRB' => '5-IRB','6-IRB' => '6-IRB', '7-IRB','ADGP office' => 'ADGP office','IGP-PAP' => 'IGP-PAP','IGP-ops' => 'IGP-ops','IGP-Trg' => 'IGP-Trg','IGP-IRB' => 'IGP-IRB','IGP-CDO' => 'IGP-CDO','DIG-Adm-PAP' => 'DIG-Adm-PAP','DIG Adm-IRB' => 'DIG Adm-IRB','DIG-Adm-CDO' => 'DIG-Adm-CDO','DIG-PAP-II & Trg.-Chg' => 'DIG-PAP-II & Trg.-Chg','Other' => 'Other'); 
                
/*newarea Textfield*/
 echo form_dropdown('ito', $ito, set_value('ito',1),'id="ito" data-placeholder="Choose One" title="Please select at least 1 value" class="select2"'); 
 echo form_error('ito');
/*----End newarea Textfield----*/
 ?>
                    <label for="ito" class="error"></label>
                  </div>
                </div>

                    
                  <div class="col-sm-3"><div class="form-group">
                 <?php  
$hn = array();
$hn[''] = '--Select Driver Name--';
                 foreach ($body as $value) {
                   $hn[$value->man_id] = 'Driver Name: '.$value->name. '&nbsp; Permanent Rank: '.$value->pr. '&nbsp; Contact No: '.$value->phone1;
                 }
                 
/*newarea Textfield*/
 echo form_dropdown('hn2', $hn, set_value('hn2',''),'id="hn2" data-placeholder="Choose One" title="Please select at least 1 value" class="select2"'); 
 echo form_error('hn2');
/*----End newarea Textfield----*/
 ?>
                    <label for="hn" class="error"></label><p id="link"></p>
                  </div>
                </div> 


                  <div class="col-sm-3"><div class="form-group">
<?php
$lsd = array('type' => 'text','name' => 'orderno','id' => 'ons','class' => 'form-control','placeholder' =>'Order No','value' => set_value('ons'));
echo form_input($lsd);
echo form_error('lsd');
?>
                    <label for="ons" class="error"></label>
                  </div>
                </div>

                  </div>

              <div class="row">
                <div class="col-sm-3">
                   <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                </div>
              </div>

                 </div>

<?php echo form_close(); ?>
          </div>
        <div class="panel-body"> 
          <!-- Example split danger button --> 
          <div class="table-responsive">
            <table class="table"  id="table">
              <thead>
                 <tr>
                    <th>S.No</th>
                    <th>Category of vehicle </th>
                    <th>Veh Class</th>
                     <th>Registeration No.</th>
                      <th>Chasis No. </th>
                      <th>Engine No.</th>
                       <th>Mode of Acquisition</th>
                        <th>Received/
Attached</th>
                         <th>Received From</th>
                         <th>Received Voucher/ RC No. or N/A</th>
                          <th>Received/ Attached  Date</th>
                           <th>Speedo/ Odometer Reading </th>
                            <th>No. of Tyres Received</th>
                             <th>Status of Vehicle</th>
                              <th> Condition of Vehicle</th>
                              <th>Status of On-Road  Vehicle</th>
                               <th>Status of Off-Road Vehicle in MT</th>
                                <th>If Condemn then Date of condemn  </th>
                                <th>Last Service Date </th>
                              <th> Last Inspection Date </th>

                 </tr>
              </thead>
              <tbody>
                <?php  $count = 0; foreach($weapon as $value): $count = $count+1; ?>
                 <tr class="odd gradeX">
                    <td><?php echo $count; ?></td>
                    <td><?php echo $value->catofvechicle; ?></td>
                    <td><?php echo $value->vechicleclass; ?></td>
                    <td><?php echo $value->regnom; ?></td>
                    <td><?php echo $value->chasisno; ?></td>
                    <td><?php echo $value->engineno; ?></td>
                    <td><?php echo $value->modeofac; ?></td>
                    <td><?php echo $value->recattached; ?></td>
                    <td><?php echo $value->recfrom; ?></td>
                    <td><?php echo $value->recvoucher; ?></td>
                    <td><?php echo $value->recattachdate; ?></td>
                    <td><?php echo $value->speedormeter; ?></td>
                    <td><?php echo $value->nooftyrerec; ?></td>
                    <td><?php echo $value->statusofvechile; ?></td>
                    <td><?php echo $value->conditionofvechile; ?></td>
                    <td><?php echo $value->statusofonroadvichile; ?></td>
                    <td><?php echo $value->statusofoffroadvichile; ?></td>
                    <td><?php echo $value->condemdate; ?></td>
                     <td><?php echo $value->lastservicedate; ?></td>
                    <td><?php echo $value->lastinspectiondate; ?></td>
                <?php endforeach; ?>
              </tbody>
           </table>
          </div><!-- table-responsive -->   
        </div><!-- panel-body -->
        </div><!-- panel -->
      </div><!-- col-sm-12 -->
    </div><!-- row -->
    </div><!-- contentpanel -->
  </div><!-- mainpanel -->
</section>
<script src="<?php echo base_url();?>webroot/js/jquery-2.1.3.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery-ui-1.10.3.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/modernizr.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/toggles.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/retina.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery.cookies.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery.mousewheel.js"></script>
<script src="<?php echo base_url();?>webroot/js/select2.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>webroot/js/bootstrap-timepicker.min.js"></script>

<script src="<?php echo base_url();?>webroot/js/custom.js"></script>

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://datatables.net/release-datatables/extensions/ColVis/js/dataTables.colVis.js"></script>
<script type="text/javascript">
jQuery(document).ready(function(){
  "use strict";
  jQuery("select").select2({width:"100%"}),
  jQuery("select").removeClass("form-control"),

  jQuery('#ircd').datepicker({dateFormat: "dd/mm/yy"});
  jQuery('#id').datepicker({dateFormat: "dd/mm/yy"});
  jQuery('#ircdi').datepicker({dateFormat: "dd/mm/yy"});
  jQuery('#idi').datepicker({dateFormat: "dd/mm/yy"});
});
   

$(document).ready(function() {
var table = $('#table').DataTable( {
         dom: 'C<"clear">Bfrtip',
       buttons: [
            {
               extend: 'excel',
                exportOptions: {
                    columns: ':visible'
                }
            },{
               extend: 'print',
                exportOptions: {
                    columns: ':visible'
                }
            },{
               extend: 'csv',
                exportOptions: {
                    columns: ':visible'
                }
            },{
               extend: 'copy',
                exportOptions: {
                    columns: ':visible'
                }
            }
        ],
        colVis: {
            exclude: [ 0 ]
        },
        scrollY: 300,
        scrollX: 800,
        columnDefs: [
    { "visible": false, "targets": '_all' }
  ]
    } );
  

});
</script>
</body>
</html>